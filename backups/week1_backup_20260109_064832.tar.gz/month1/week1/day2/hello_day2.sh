#!/usr/bin/bash

echo "Hello from Month 1 Day 2 on Ubuntu!"
echo "Current user: $(whoami)"
echo "Current directory $(pwd)"
