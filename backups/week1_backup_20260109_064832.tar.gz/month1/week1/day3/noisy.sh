#!/usr/bin/env bash

echo "This is normal output"
ls definitely_not_a_real_file
echo "This line is after the error"
